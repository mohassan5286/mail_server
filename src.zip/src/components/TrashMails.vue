<template>
    <div class="pageTrashMails">
        <nav class="navbar">
          <div class="container-fluid">
            <form class="d-flex" role="search">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Search</button>
    
              <!-- Search By Dropdown -->
              <div class="dropdown" id="searchBy">
                <button type="button" class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">{{ searchByText }}</button>
                <ul class="dropdown-menu">
                  <li @click="updateSearchBy('Date')" class="dropdown-item">Date</li>
                  <li @click="updateSearchBy('Sender')" class="dropdown-item">Sender</li>
                  <li @click="updateSearchBy('Subject')" class="dropdown-item">Subject</li>
                  <li @click="updateSearchBy('Body')" class="dropdown-item">Body</li>
                  <li @click="updateSearchBy('Importance')" class="dropdown-item">Importance</li>
                </ul>
              </div>
  
              <!-- Search By Dropdown -->
              <input class="form-control me-2" id = "test" type="search" placeholder="Filter" aria-label="Search">
              <button class="btn btn-outline-warning" type="submit">Filter</button>  
              
              <div class="dropdown" id="filterBy">
                <button type="button" class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">{{ filterByText }}</button>
                <ul class="dropdown-menu">
                  <li @click="updateFilterBy('Date')" class="dropdown-item">Date</li>
                  <li @click="updateFilterBy('Sender')" class="dropdown-item">Sender</li>
                  <li @click="updateFilterBy('Subject')" class="dropdown-item">Subject</li>
                  <li @click="updateFilterBy('Body')" class="dropdown-item">Body</li>
                  <li @click="updateFilterBy('Importance')" class="dropdown-item">Importance</li>
                </ul>
              </div>
  
              <h3>Trash</h3>

              <div class="dropdown" id = "type">
                <button type="button" class="btn btn-outline-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">{{ typeText }}</button>
                <ul class="dropdown-menu">
                  <li @click = "updateType('Default')"  class="dropdown-item">Default</li>
                  <li @click = "updateType('Priority')" class="dropdown-item">Priority</li>
                </ul>
              </div>
            
              <!-- Sort By Dropdown -->
              <div class="dropdown" id="sortBy"> 
                <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ sortByText }}</button>
                <ul class="dropdown-menu">
                  <li @click="updateSortBy('Date')" class="dropdown-item">Date</li>
                  <li @click="updateSortBy('Sender')" class="dropdown-item">Sender</li>
                  <li @click="updateSortBy('Subject')" class="dropdown-item">Subject</li>
                  <li @click="updateSortBy('Body')" class="dropdown-item">Body</li>
                  <li @click="updateSortBy('Importance')" class="dropdown-item">Importance</li>
                </ul>
              </div>
            </form>
          </div>
        </nav>
      </div>
  </template>
    
  <script>
  
      export default {
          data() {
          return {
              searchByText: 'By',
              sortByText: 'Sort by',
              filterByText: 'By',
              typeText: 'Default',
              TrashMails: false
          };
          },
          methods: {
            updateSearchBy(value) {
                this.searchByText = value;
            },
            updateSortBy(value) {
                this.sortByText = value;
            },
            updateFilterBy(value) {
                this.filterByText = value;
            },
            updateType(value) {
                this.typeText = value;
            },
  
          },
      };
  </script>
    
  <style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Grand+Hotel&display=swap');
      .pageTrashMails {
          top: 15%;
          display: none;
          width: 70%;
          height: 80%;
          left: 300px;
          position: absolute;
          border: 3px solid black;
          border-radius: 30px;
          box-shadow: 10px 10px 10px 10px;
      }

      h3{
        color: rgb(0, 0, 0);
        margin-left: 150px;
        font-family: 'Grand Hotel';
      }
      
      .navbar {
          border: 1px solid;
          border-radius: 30px 30px 0 0 ;
          border-bottom: 2px solid rgb(37, 37, 37);
          height: 100px;
      }
      
      #searchBy {
          margin-left: 5px;
          margin-right: 10px;
      }
  
      #filterBy{
        margin-left: 5px;
      }
      
      #sortBy {
          margin-left: 20px;
      }
      
      #delete {
          margin-left: 20px;
      }
  
      #type{
        margin-left: 170px;  
      }
  
  
      
  </style>
    